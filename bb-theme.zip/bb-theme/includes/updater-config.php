<?php

if ( class_exists( 'FLUpdater' ) ) {
	FLUpdater::add_product(array(
		'name'    => 'Beaver Builder Theme',
		'version' => '1.7.19.2',
		'slug'    => 'bb-theme',
		'type'    => 'theme',
	));
}
